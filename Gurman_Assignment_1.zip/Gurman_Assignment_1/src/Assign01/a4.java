package Assign01;
import java.util.Scanner;

public class a4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b,t;
		System.out.println("a :");
        a = sc.nextInt();
        System.out.println("b :");
        b = sc.nextInt();
        t=a+b;
        if(a>=13&&a<=19)
        	System.out.println("teensum :19");
        else if(b>=13&&b<=19)
        	System.out.println("teensum :19");
        else
        	System.out.println("teensum :"+t);
        
		
		sc.close();
	}

}
