package Assign01;
import java.util.Scanner;

public class a2 {
	public static void main(String[] args) {
		double q,p,t;
        Scanner sc = new Scanner(System.in);
        System.out.println("Quantity :");
        q = sc.nextDouble();
        System.out.println("Purchased :");
        p = sc.nextDouble();
        
        if(q>=1000) {
        	q=q*0.9;
        }
        
        t=q*p;
        
        System.out.println("Total Expenses :"+t);
        
        sc.close();      
}
}
