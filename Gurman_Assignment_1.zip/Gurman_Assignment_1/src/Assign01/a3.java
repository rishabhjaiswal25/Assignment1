package Assign01;
import java.util.Scanner;

public class a3 {
	public static void main(String[] args) {
		int cn,n;
		Scanner sc = new Scanner(System.in);
        System.out.println("Current Number :");
        cn = sc.nextInt();
        
        if(cn%2==0) {
        	n=cn/2;
        }
        else {
        	n=3*cn+1;
        }
        
        System.out.println("Number :"+n);
        
        sc.close();
	}

}
