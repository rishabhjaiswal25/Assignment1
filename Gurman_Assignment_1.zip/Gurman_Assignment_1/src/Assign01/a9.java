package Assign01;

import java.util.Scanner;

public class a9 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		a= sc.nextInt();
        
        if(a==9||a==10)
        System.out.println("Excellent");
        else if(a==7||a==8)
            System.out.println("Notable");
        else if(a==6)
            System.out.println("Good");
        else if(a==5)
            System.out.println("Approved");
        else if(a>=0&&a<=4)
            System.out.println("Fail");
        else
            System.out.println("Invalid");
       
        sc.close();
        }

}
