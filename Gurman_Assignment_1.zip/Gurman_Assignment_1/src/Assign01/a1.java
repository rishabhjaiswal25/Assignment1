package Assign01;
import java.util.Scanner;

public class a1 {
	public static void main(String[] args) {
		int m;
        Scanner sc = new Scanner(System.in);
        System.out.println("Code ");
        m = sc.nextInt();
        if(m==1) {
        	double x,y,sum;
        	System.out.println("X : ");
            x = sc.nextDouble();
            
            System.out.println("Y : ");
            y = sc.nextDouble();
            
            sum=x+y;
            System.out.println("Sum : "+sum);
        }
        
        else {
        	System.out.println("Sum : 0.00 ");
        }
        
        
        
        sc.close();
		

	}
}
