package gurman_assign01;
import java.util.Scanner;

public class a5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Enter the cost of the mobile :");
        a = sc.nextInt();
        
        if(a<=15000)
        System.out.println("Mobile chosen is within the budget");
        else
        	System.out.println("Mobile chosen is beyond the budget");
       
        sc.close();
        }

}
