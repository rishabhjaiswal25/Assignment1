package gurman_assign01;
import java.util.Scanner;

public class a7 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a;
		System.out.println("Enter the color :");
		a= sc.next();
		sc.nextLine();
				
		if(a.equals("green")){
            System.out.println("Go");
        }
        else if(a.equals("red"))
            System.out.println("Stop");
        else if(a.equals("yellow"))
            System.out.println("proceed with caution");
        else if(a.equals("white"))
            System.out.println("prepare to go");
       
        sc.close();
        }

}
